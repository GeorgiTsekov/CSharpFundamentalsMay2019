﻿using P03ShoppingSpree.Core;

namespace P03ShoppingSpree
{
    class Program
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
