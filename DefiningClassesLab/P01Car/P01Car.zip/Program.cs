﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {

            Car firstCar = new Car();
            firstCar.Drive(1000);

            Car secondCar = new Car("Renaut", "Megan", 2000);
            Car thirdCar = new Car("Audi", "A6", 2004, 82.5, 6.7);
            Console.WriteLine(firstCar.WhoAmI());
            Console.WriteLine(secondCar.WhoAmI());
            Console.WriteLine(thirdCar.WhoAmI());
        }
    }
}
